/**
 * File: Essentials.java
 * File Created: Tuesday, 21 January 2020 18:00 PM
 * @author Wisdom Kalu
 * @version 1.0
 * Modified By: Wisdom Tochi Kalu
 * Last Modified: Wednesday, 22 January 2020 20:24 PM
 * Copyright @2020 Wisdom Tochi Kalu
 * Brief:
 * ------
 * This program helps automate the buying and selling process from the Essentials shop at fifi
 * It gets what the user wants to buy and stores all the information of the purchase made by the
 * user. Then, it reads from the stored file and displays the information to the shop keeper
 * ------
 */

import java.util.InputMismatchException;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.io.FileOutputStream;
import java.io.File;

public class Essentials {
    public String item;
    public int quantity;
    public double price;

    /**
     * A defualt constructor 
     */
    public Essentials() { }

    /**
     * A constructor with parameters
     * @param item initialises the name of the item 
     * @param quantity Initialises the quantity of the item 
     * @param price Initialises the price of the commodity
     */
    public Essentials(String item, int quantity, double price) {
        this.item = item;
        this.quantity = quantity;
        this.price = price;
    }

    /**
     * @param x A method to hold the item entered by the user. 
     * The parameter x holds reference to the item entered
     */
    public void setItem (String x) {
        this.item = x;
    }
/**
 * This code returns the name of the item entered
 * @return Returns item entered by user
 */
    public String getItem() {
        return item;
    }

    /**
     * This is a setter method for the quantity entered by user
     * @param y The variable y holds the item entered by user
     */
    public void setQuantity (int y) {
        this.quantity = y;
    }

    /**
     * This is a getter method for the quantity entered by user
     * @return It returns the quantity entered by user
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * This is a setter method for the price of the item
     * @param z The parameter z holds the price of the item entered by the user
     */
    public void setPrice (double z) {
        this.price = z;
    }
   
    /**
     * This is a getter method for the price
     * @return It returns the price of the items as entered by the user
     */
    public double getPrice() {
        return price;
    }


/**
 * A method that creates a backup file and copies it into a new file
 */
    public void copyFile () {
        File cfile=new File("backup_essentials_stock.txt");
        File ofile=new File("Essentials_stock.txt");
        try {
            Files.copy(ofile.toPath(), cfile.toPath(), StandardCopyOption.REPLACE_EXISTING);

        } catch (Exception e) {
            System.out.println("unable to copy");
        }

    }


    /**
     * This code reads from the file that contains items purchased by user
     * It contains a try and catch method to handle the case when the given 
     * File cannot be found. It uses a scanner class to read from the file
     * aand desplays the items on the console
     */
    public void readFromFiles() { 
    try {
          
        File file = new File("C:\\Users\\tochi\\Desktop\\Wisdom_Kalu\\Essentials_stock.txt"); // passes the path to the file as a parameter 
        Scanner sc = new Scanner(file); 
      
        while (sc.hasNext()) // loops through each line of the file and reads from the file
          System.out.println(sc.nextLine()); 
        //   System.out.println("test while");
     } catch (FileNotFoundException e) {
         System.out.println("WARNING: FILE NOT FOUND!!!");
     }
       
    }

/**
 * 
 * @param args A test method for the Essentials class
 */


public static void main(String[] args) {
try {
    Essentials wisd = new Essentials();
    PrintWriter printWriter = null;
    printWriter = new PrintWriter(new FileOutputStream("Essentials_stock.txt", true));

    printWriter.printf("ITEM " + "   " + " QUANTITY " +"   " + " PRICE ");
    printWriter.println();

    
    
     /**
     * A scanner method to get the item from the user
     * This code will get items, quantity and price from the user
    */
     for (int j =0; j<10; j++) {
         Scanner input = new Scanner(System.in);
         System.out.print("Enter Items at the Shop: ");

         String str = input.nextLine();
         System.out.print("Enter the Quantity: ");

         int i = input.nextInt();
         System.out.print("Enter the Price: ");
         double d = input.nextDouble();

         /**
          * Setter methods to set item, price and quantity as given by the user
          */
         wisd.setItem(str);
         wisd.setQuantity(i);
         wisd.setPrice(d);
        

          /**
      * Method to get the items supplied by the user and write them into a file supplied
      * using the printwriter method
      */
     printWriter.printf(wisd.getItem() + "      " + wisd.getQuantity() + "       " + wisd.getPrice());
     printWriter.println();
     }

     wisd.readFromFiles();
    wisd.copyFile();

    /**
     * Writing to the file.....
     */
    System.out.println();
    System.out.println("---Writing to file---");
    System.out.println("COMPLETED!");

    /**
     * The code below reads from the file already saved in the computer
     */
    System.out.println();
    System.out.println("---Reading from file---");
    wisd.readFromFiles();

    printWriter.close(); // closes the printwriter class
} 

/**
 * The code below is an exception catcher when the intended file is not found
 */
    catch (FileNotFoundException e) {
        System.out.println("WARNING: FILE NOT FOUND!!!"); 
    }
    catch (InputMismatchException e) {
        System.out.println("WARNING: INPUT MISMATCH!!!");

  }

}
}